from ninja import NinjaAPI

api = NinjaAPI(title="SilverLand Property Assistant API")
